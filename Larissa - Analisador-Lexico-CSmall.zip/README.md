# Analisador Léxico CSmall
Trabalho da disciplina de Compiladores (2018/1)

Para executar:
```
python main.py
```

Em seguida, digite o nome do arquivo que deseja analisar.
